package com.exam.examserver.service.imp;

import java.util.LinkedHashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.exam.examserver.Repo.CategoryRepo;
import com.exam.examserver.model.exam.Category;
import com.exam.examserver.service.CategoryService;
@Service
public class CategoryServiceImpl implements CategoryService{

	@Autowired
	private CategoryRepo categoryRepo;
	
	@Override
	public Category addCaategory(Category category) {
		// TODO Auto-generated method stub
		return this.categoryRepo.save(category);
	}

	@Override
	public Category updateCategory(Category category) {
		return this.categoryRepo.save(category); 
	}

	@Override
	public Set<Category> getCategories() {
		
		return new LinkedHashSet<>( this.categoryRepo.findAll());
	}

	@Override
	public Category getCategory(Long categoryId) {
		
		return this.categoryRepo.findById(categoryId).get();
	}

	@Override
	public void deleteCategory(Long categoryId) {
		Category category1=new Category();
		category1.setCid(categoryId);
		this.categoryRepo.delete(category1);
		
	}

}
