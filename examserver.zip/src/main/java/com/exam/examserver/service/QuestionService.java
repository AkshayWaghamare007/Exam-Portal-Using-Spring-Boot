package com.exam.examserver.service;

import java.util.Set;

import com.exam.examserver.model.exam.Questions;
import com.exam.examserver.model.exam.Quiz;

public interface QuestionService {

	public Questions addQuestions(Questions questions);
	
	public Questions updateQuestions(Questions questions);
	
	public Set<Questions> getQuestions();
	
	public Questions getQuestions(Long questionId);
	
	public Set<Questions>  getQuestionsQuiz(Quiz quiz);
	
	public void deleteQuestion(Long quesId);
	
	public Questions get(Long questionsId);
}
