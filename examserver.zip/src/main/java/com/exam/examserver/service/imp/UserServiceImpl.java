package com.exam.examserver.service.imp;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.exam.examserver.Repo.RoleRepo;
import com.exam.examserver.Repo.UserRepo;
import com.exam.examserver.model.User;
import com.exam.examserver.model.UserRole;
import com.exam.examserver.service.UserService;

@Service
public class UserServiceImpl implements UserService{

	@Autowired
	private UserRepo userRepo;
	
	@Autowired
	private RoleRepo roleRepo;
	
	@Override
	public User createUser(User user, Set<UserRole> userRoles) throws Exception {
	User local=	this.userRepo.findByUsername(user.getUsername());
	if(local !=null)
	{
		System.out.println("User is alredy there!!..");
		throw new Exception("User alredy present !!");
	}
	else
	{
		for(UserRole ur:userRoles)
		{
			roleRepo.save(ur.getRole());
		}
		
		user.getUserRoles().addAll(userRoles);
		local= this.userRepo.save(user);
		
	}
	return local;
	}

	@Override
	public User getUser(String Username){
		
		return this.userRepo.findByUsername(Username);
	}

	@Override
	public void deleteUser(Integer id) {
		this.userRepo.deleteById(id);
		
	}

	
	
}
