package com.exam.examserver.service.imp;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.exam.examserver.Repo.QuestionRepo;
import com.exam.examserver.model.exam.Questions;
import com.exam.examserver.model.exam.Quiz;
import com.exam.examserver.service.QuestionService;

@Service
public class QuestionServiceImpl implements QuestionService{

	@Autowired
	private QuestionRepo questionRepo;
	
	@Override
	public Questions addQuestions(Questions questions) {
		// TODO Auto-generated method stub
		return this.questionRepo.save(questions);
	}

	@Override
	public Questions updateQuestions(Questions questions) {
		// TODO Auto-generated method stub
		return this.questionRepo.save(questions);
	}

	@Override
	public Set<Questions> getQuestions() {
		// TODO Auto-generated method stub
		return new HashSet<>(this.questionRepo.findAll());
	}

	@Override
	public Questions getQuestions(Long questionId) {
		// TODO Auto-generated method stub
		return this.questionRepo.findById(questionId).get();
	}

	@Override
	public Set<Questions> getQuestionsQuiz(Quiz quiz) {
		return this.questionRepo.findByQuiz(quiz);
	}

	@Override
	public void deleteQuestion(Long quesId) {
		Questions questions=new Questions();
		questions.setQuesId(quesId);
		this.questionRepo.delete(questions);
	}

	@Override
	public Questions get(Long questionsId) {
		return this.questionRepo.getOne(questionsId);
	}

}







