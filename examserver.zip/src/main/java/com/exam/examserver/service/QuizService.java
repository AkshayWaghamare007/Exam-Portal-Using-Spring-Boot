package com.exam.examserver.service;



import java.util.List;
import java.util.Set;

import com.exam.examserver.model.exam.Category;
import com.exam.examserver.model.exam.Quiz;

;

public interface QuizService {

	public Quiz addQuize(Quiz quiz);
	
	public Quiz updateQuize(Quiz quiz);
	
	public Set<Quiz> getQuizze();
	
	public Quiz getQuize(long quizId);
	
	public void deleteQuize(long quizId);

	public List<Quiz> getQuizzesOfCategory(Category category);
	
	public List<Quiz> getActiveQuizzes();
	
	public List<Quiz> getActiveQuizzesOfCategory(Category  c);


}
