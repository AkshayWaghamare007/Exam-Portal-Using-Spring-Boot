package com.exam.examserver.Repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.exam.examserver.model.exam.Category;

public interface CategoryRepo extends JpaRepository<Category, Long>{

}
