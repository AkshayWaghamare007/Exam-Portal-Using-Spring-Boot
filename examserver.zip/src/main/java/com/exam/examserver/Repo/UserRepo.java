package com.exam.examserver.Repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.exam.examserver.model.User;

public interface UserRepo extends JpaRepository<User, Integer>{

	public User findByUsername(String username);
}
