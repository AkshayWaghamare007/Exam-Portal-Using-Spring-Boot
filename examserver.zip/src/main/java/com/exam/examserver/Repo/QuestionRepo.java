package com.exam.examserver.Repo;

import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;

import com.exam.examserver.model.exam.Questions;
import com.exam.examserver.model.exam.Quiz;

public interface QuestionRepo extends JpaRepository<Questions, Long>{

	Set<Questions> findByQuiz(Quiz quiz);

}
