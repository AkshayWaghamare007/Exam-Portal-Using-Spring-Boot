package com.exam.examserver.controller;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.exam.examserver.config.jwtUtils;
import com.exam.examserver.model.User;
import com.exam.examserver.model.jwtRequest;
import com.exam.examserver.model.jwtResponse;
import com.exam.examserver.service.imp.UserDetailsServiceImpl;

@RestController
@CrossOrigin("*")
public class AuthenticateController {
	@Autowired
	private AuthenticationManager authenticationManager;
	
	@Autowired
	private UserDetailsServiceImpl userDetailsServiceImpl;
	
	
	@Autowired
	private jwtUtils jwtUtils;
	
	
	@PostMapping("/generate-token")
	public ResponseEntity<?> geneerateToken(@RequestBody jwtRequest jwtRequest) throws Exception
	{
		try {
			
			authenticate(jwtRequest.getUsername(), jwtRequest.getPassword());
			
		} 
		catch(UsernameNotFoundException e) {
		
			e.printStackTrace();
		throw new Exception("User not Found");
			
		}catch (Exception e) {
			e.printStackTrace();
			throw new Exception("User not Found");
		}
		
	UserDetails userDetails= this.userDetailsServiceImpl.loadUserByUsername(jwtRequest.getUsername());
String token=this.jwtUtils.generateToken(userDetails);
  return ResponseEntity.ok(new jwtResponse(token));
	
	
	}
	
	
	
	private void  authenticate(String username,String password) throws Exception
	{
		try {
			authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, password));
		} catch (DisabledException e) {
			throw new Exception("USER DISABLED"+e.getMessage());
		}
		catch (BadCredentialsException e) {
			throw new Exception("Invalid Creditials"+e.getMessage());
		}
	}
	
	@GetMapping("/current-user")
	public User getCurrenUser(Principal p)
	{
	    return((User) this.userDetailsServiceImpl.loadUserByUsername(p.getName()));
	}
}
