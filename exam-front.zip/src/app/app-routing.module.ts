import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddCategoriesComponent } from './pages/Admin/add-categories/add-categories.component';
import { AddQuestionsComponent } from './pages/Admin/add-questions/add-questions.component';
import { AddQuizComponent } from './pages/Admin/add-quiz/add-quiz.component';
import { DashboardComponent } from './pages/Admin/dashboard/dashboard.component';
import { UpdateQuizComponent } from './pages/Admin/update-quiz/update-quiz.component';
import { ViewCategoriesComponent } from './pages/Admin/view-categories/view-categories.component';
import { ViewQuestionComponent } from './pages/Admin/view-question/view-question.component';
import { ViewQuizzesComponent } from './pages/Admin/view-quizzes/view-quizzes.component';
import { WelcomeComponent } from './pages/Admin/welcome/welcome.component';
import { HomeComponent } from './pages/home/home.component';
import { LoginComponent } from './pages/login/login.component';
import { ProfileComponent } from './pages/profile/profile.component';
import { SignupComponent } from './pages/signup/signup.component';
import { InstroctionsComponent } from './pages/User/instroctions/instroctions.component';
import { LoadQuizComponent } from './pages/User/load-quiz/load-quiz.component';
import { StartComponent } from './pages/User/start/start.component';
import { UserDashboardComponent } from './pages/User/user-dashboard/user-dashboard.component';
import { AdminGuard } from './service/admin.guard';
import { NormalGuard } from './service/normal.guard';

const routes: Routes = [

{
  path:'signup',
  component:SignupComponent,
  pathMatch:'full',
},
{
  path:'login',
  component:LoginComponent,
  pathMatch:'full',
},
{
  path:'',
  component:HomeComponent,
  pathMatch:'full',
},
{
  path:'admin',
  component:DashboardComponent,
  canActivate:[AdminGuard],
  children:[
    {
path:'',
component:WelcomeComponent,

    },
    {
      path:'profile',
      component:ProfileComponent,
    },
    {
      path:'categories',
      component:ViewCategoriesComponent
    },
    {
      path:'add-category',
      component:AddCategoriesComponent,
    },
    {
      path:'quizzes',
      component:ViewQuizzesComponent,
    },
    {
      path:'add-quiz',
      component:AddQuizComponent,
    },

    {
      path:'quiz/:qid',
      component:UpdateQuizComponent,
    },
    {
      path:'view-questions/:qid/:title',
      component:ViewQuestionComponent,
    },
    {
      path:'add-question/:qid/:title',
      component:AddQuestionsComponent,
    }

  ]
},
{
  path:'user-dashboard',
  component:UserDashboardComponent,
  canActivate:[NormalGuard],
  children:[
    {
      path:':catId',
      component:LoadQuizComponent,
    },
    {
      path:'instructions/:qid',
      component:InstroctionsComponent,
    },


  ]
},
{
  path:'start/:qid',
  component:StartComponent,
  canActivate:[NormalGuard],
}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
