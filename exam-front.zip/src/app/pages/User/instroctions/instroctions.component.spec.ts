import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InstroctionsComponent } from './instroctions.component';

describe('InstroctionsComponent', () => {
  let component: InstroctionsComponent;
  let fixture: ComponentFixture<InstroctionsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InstroctionsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InstroctionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
