import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { QuizService } from 'src/app/service/quiz.service';

@Component({
  selector: 'app-load-quiz',
  templateUrl: './load-quiz.component.html',
  styleUrls: ['./load-quiz.component.css']
})
export class LoadQuizComponent implements OnInit {
  catId:any
  cid:any;
  quizzes:any;
  constructor(private _route:ActivatedRoute,private _quiz:QuizService) { }

  ngOnInit(): void {

    this._route.params.subscribe((params)=>{
      this.catId= params['catId'];
      if(this.catId==0){
        this._quiz.getActiveQuizzes().subscribe((data:any)=>{
          this.quizzes=data;
          console.log(this.quizzes);

        },
        (error)=>{
          console.log(error);
          alert("quize loading error")

        }

        )
            }
            else
            {
              console.log('load error');

              this._quiz.getActiveQuizzesOfCategory(this.catId).subscribe((data:any)=>{
                this.quizzes=data;
              },
              (error)=>{
                alert('error in loading quiz data');
              }
              )
            }
    })


  }

}
