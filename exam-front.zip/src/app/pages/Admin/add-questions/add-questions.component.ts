import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { QuestionServiceService } from 'src/app/service/question-service.service';
import { QuizService } from 'src/app/service/quiz.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-add-questions',
  templateUrl: './add-questions.component.html',
  styleUrls: ['./add-questions.component.css']
})
export class AddQuestionsComponent implements OnInit {
qId:any;
qTitle:any;
question:any={
  quiz:{},
  content:'',
  option1:'',
  option2:'',
  option3:'',
  option4:'',
  answer:'',

};

  constructor(private _route:ActivatedRoute,private _question:QuestionServiceService) { }

  ngOnInit(): void {

    this.qId=this._route.snapshot.params['qid'];
    this.qTitle=this._route.snapshot.params['title'];
    this.question.quiz['qId']=this.qId;
  }


  formSubmit(){
    this._question.addQuestion(this.question).subscribe((data:any)=>{
      Swal.fire('Success','Question Added ','success');
    },
    (error)=>{
      Swal.fire('Error','Error in adding question','error');
    }
    )
  }



}
