import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatButtonModule} from '@angular/material/button';
import { NavbarComponent } from './components/navbar/navbar.component';
import { FooterComponent } from './components/footer/footer.component';
import { SignupComponent } from './pages/signup/signup.component';
import { LoginComponent } from './pages/login/login.component';
import {MatInputModule} from '@angular/material/input';
import {MatFormFieldModule} from '@angular/material/form-field';
import { FormsModule } from '@angular/forms';
import {HttpClientModule, HTTP_INTERCEPTORS} from '@angular/common/http'
import {MatSnackBarModule} from '@angular/material/snack-bar';
import Swal from 'sweetalert2';
import { HomeComponent } from './pages/home/home.component'
import { MatCardModule} from '@angular/material/card';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatIconModule} from '@angular/material/icon';
import { LoginService } from './service/login.service';
import { AuthInterceptor } from './service/auth.interceptor';
import { UserDashboardComponent } from './pages/User/user-dashboard/user-dashboard.component';
import { DashboardComponent } from './pages/Admin/dashboard/dashboard.component';
import { ProfileComponent } from './pages/profile/profile.component';
import {MatListModule} from '@angular/material/list';
import { SidebarComponent } from './pages/Admin/sidebar/sidebar.component';
import { WelcomeComponent } from './pages/Admin/welcome/welcome.component';
import { ViewCategoriesComponent } from './pages/Admin/view-categories/view-categories.component';
import { AddCategoriesComponent } from './pages/Admin/add-categories/add-categories.component';
import { ViewQuizzesComponent } from './pages/Admin/view-quizzes/view-quizzes.component';
import { AddQuizComponent } from './pages/Admin/add-quiz/add-quiz.component';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import {MatSelectModule} from '@angular/material/select';
import { UpdateQuizComponent } from './pages/Admin/update-quiz/update-quiz.component';
import { ViewQuestionComponent } from './pages/Admin/view-question/view-question.component';
import { AddQuestionsComponent } from './pages/Admin/add-questions/add-questions.component';
import { CKEditorModule } from '@ckeditor/ckeditor5-angular';
import { SidebarComponent as userSidebar} from './pages/User/sidebar/sidebar.component';
import { LoadQuizComponent } from './pages/User/load-quiz/load-quiz.component';
import { InstroctionsComponent } from './pages/User/instroctions/instroctions.component';
import { StartComponent } from './pages/User/start/start.component';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import { NgxUiLoaderModule } from 'ngx-ui-loader';
import {  NgxUiLoaderHttpModule } from "ngx-ui-loader";
@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    FooterComponent,
    SignupComponent,
    LoginComponent,
    HomeComponent,
    UserDashboardComponent,
    DashboardComponent,
    ProfileComponent,
    SidebarComponent,
    WelcomeComponent,
    ViewCategoriesComponent,
    AddCategoriesComponent,
    ViewQuizzesComponent,
    AddQuizComponent,
    UpdateQuizComponent,
    ViewQuestionComponent,
    AddQuestionsComponent,
    userSidebar,
    LoadQuizComponent,
    InstroctionsComponent,
    StartComponent



  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatButtonModule,
    MatInputModule,
    MatFormFieldModule,
    FormsModule,
    HttpClientModule,
    MatSnackBarModule,
    MatCardModule,
    MatToolbarModule,
    MatIconModule,
    MatListModule,
    MatSlideToggleModule,
    MatSelectModule,
    CKEditorModule,
    MatProgressSpinnerModule,
    NgxUiLoaderModule,
    NgxUiLoaderHttpModule.forRoot({
      showForeground:true,
    })
  ],
  providers: [LoginService ,  [{ provide:HTTP_INTERCEPTORS, useClass:AuthInterceptor, multi:true }]],
  bootstrap: [AppComponent]
})
export class AppModule { }
